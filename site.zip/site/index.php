<?php
require_once("dbtools.php");
$texte_citation=lire_citation(10);
$auteur_citation=lire_auteur_citation(10);
$texte_roman=lire_roman(10);
$auteur_roman=lire_auteur_roman(10);
$titre_roman=lire_titre_roman(10);
$date_roman=lire_oeuvre_date_roman(10);

$bg_url = "images/bg/background".mt_rand(1,12).".jpg";

?>
<!DOCTYPE html>
<html lang="fr">
	<head>
		<title>ILIOS</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<meta http-equiv="refresh" content="10">
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>

		<style>
		.Reste{
			font-family: 'Theo';
			font-size: 1.2rem;
			color: #ffffff;
			font-weight: 600;
			line-height: 1.5;
			margin: 0 0 1rem 0;
			letter-spacing: 0.1rem;
		}
		.Ilios{
			font-family: 'Vincent';
		  }
		  
		.custom-bg::after {
 			   background-image: url(<?php echo $bg_url; ?>) !important;
		}
		</style>


	</head>
	<body>

		<!-- Wrapper -->
			<div id="wrapper">

						<!-- Contact -->
<!--
 							<article id="contact">
								<h2 class="major">Contact</h2>
								<form method="post" action="#">
									<div class="field half first">
										<label for="name">Name</label>
										<input type="text" name="name" id="name" />
									</div>
									<div class="field half">
										<label for="email">Email</label>
										<input type="text" name="email" id="email" />
									</div>
 									<div class="field">
										<label for="message">Message</label>
										<textarea name="message" id="message" rows="4"></textarea>
									</div>
 									<ul class="actions">
										<li><input type="submit" value="Send Message" class="special" /></li>
										<li><input type="reset" value="Reset" /></li>
									</ul>
								</form>
							</article> 
-->

				<header id="header">
					<div class="logo">
						<ul class="actions">
						<a href="#intro"><div align="center"><img src="images/SUN_ILIOS.png" width="110"/></div></a>
						</ul>
					</div>

					<div class="content">
						<div class="inner">
<!--
							<h1>Ton rayon de soleil intelligent,</h1> 
							<h1>tous les matins</h1>
-->
							<h2><?php echo $texte_citation; ?><br/></h2>
							<span class="change"><h6><div align="right"><?php echo $auteur_citation; ?></div></h6></span>
						</div>
						
						<a href="#work"><div align="right"><img src="images/read.png" width="70"/></div></a>
<!--
							<div align="center">
								<a href="#intro"><img src="images/citation.png" width="30"/></a>
								<a href="#intro"><img src="images/defi.png" width="30"/></a>
								<a href="#intro"><img src="images/mot.png" width="30"/></a>
							</div>
-->
					</div>


				</header>

				<!-- Main -->
				<div id="main">

					<!-- Intro -->
					<article id="intro">
							<span class="image main"><div align="center"><img src="images/Ilios_logo2 copy.psd" alt="" /></div></span>

<!-- 						<a href="#intro"><div align="center"><img src="images/Ilios_logo2 copy.psd" width="600"/></div></a>
 -->						<h6><div align="center">Tous les matins, ton rayon de soleil.</div></h6>

						<div style="text-align: center">
							<span class="Reste">Te souviens-tu de la dernière lecture intéressante qui t'a fait porter un regard neuf sur ce qui t'entoure? De la sensation et du changement qu'elle a provoqués en toi? </span><br/><br/>
							<div style="text-align: justify"><span class="Ilios">J</span><span class="Reste">e m’appelle Ilios, ce qui signifie soleil en grec. Je m'engage à te proposer du contenu éclairant que j’aurai soigneusement choisi pour que tu puisses, tous les matins, voir le monde un peu différemment. </span><br/>
								<span class="Ilios">J</span><span class="Reste">e te propose donc de devenir ton rayon de soleil quotidien. De faire en sorte que l'anodin devienne merveilleux, le commun étonnant. Ainsi, à ton réveil, tu pourras lire ma citation préférée et lorsque tu as quelques minutes supplémentaires à t'accorder, ouvre le petit livre sous la citation pour découvrir une lecture incoutournable que je te recommande chaudement.</span><br/>
								<span class="Ilios">J</span><span class="Reste">e suis joueur, il arrivera donc de temps à autres que je te surprennes avec des petits défis pour te pousser à sortir de ta zone de confort, aller vers les autres, dans le but de savourer l'instant présent!</span><br/>
								<span class="Ilios">J</span><span class="Reste">e suis encore jeune, et peut être maladroit parfois, s'il te plaît écris-moi en cliquant sur la lettre un petit peu plus bas pour me faire part de tes coups de coeurs, recommendations et commentaires positifs ou negatifs! Je t'en remercie!  </span><br/><br/>
								<span class="Reste">À</span><span class="Reste">ujourd'hui est un jour magnifique, je te souhaite une journée ensoleillée de belles découvertes!</span><br/><br/>
							</div>
						</div>

 							
						<h6>  <div align="left">À bientôt.</div></h6>
						<h5><div align="right">Ilios </div></h5></br>

						<a href="mailto:Ilios@ilios.io"><div align="center"><img src="images/Ilios_courriel.png" width="70"/></div></a>
					</article>

						<!-- Work -->
							<article id="work">
								<h5><center>Tes cinq minutes de lecture inspirantes</center></h5>
								<h2 class="major"></h2>


								<h2 class="major"><?php echo $titre_roman; ?></h2>
                                <h3><div align="right"><?php echo $date_roman; ?></div></h3>
                                        <h3><div align="justify">-<?php echo $texte_roman; ?>

                                        </h3>
                                        <h5><div align="right"><?php echo $auteur_roman; ?></h5>
<!-- 								<h2 class="major">Le chat</h2>
								<h3><div align="right">blabla</div></h3>
								<h3><div align="justify">kjnsdonzeopnfpzeonf,

								</h3>
								<h5><div align="right">kbefiubfzepiubfez</h5> -->
							</article>

						<!-- About -->
							<article id="about">
								<h2 class="major">About</h2>
								<span class="image main"><img src="images/pic03.jpg" alt="" /></span>
								<p>...</p>
							</article>

						<!-- Contact -->
							<article id="contact">
								<h2 class="major">Contact</h2>
								<form method="post" action="#">
									<div class="field half first">
										<label for="name">Name</label>
										<input type="text" name="name" id="name" />
									</div>
									<div class="field half">
										<label for="email">Email</label>
										<input type="text" name="email" id="email" />
									</div>
									<div class="field">
										<label for="message">Message</label>
										<textarea name="message" id="message" rows="4"></textarea>
									</div>
									<ul class="actions">
										<li><input type="submit" value="Send Message" class="special" /></li>
										<li><input type="reset" value="Reset" /></li>
									</ul>
								</form>
								<ul class="icons">
									<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
									<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
									<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
									<li><a href="#" class="icon fa-github"><span class="label">GitHub</span></a></li>
								</ul>
							</article>

					</div>

				<!-- Footer -->
					<footer id="footer">
<!--
 						<p class="copyright">&copy; Untitled. Design: <a href="http://vpicouet.perso.centrale-marseille.fr/blog/index.html">T. Corboliou & V. Picouet</a>.</p>
 -->
					</footer>

			</div>

		<!-- BG -->
			<div id="bg" class="custom-bg"></div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>